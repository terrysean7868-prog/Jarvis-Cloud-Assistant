# Jarvis Cloud Assistant

Repo name: Jarvis-Cloud-Assistant
Telegram bot username: MyJarvisCloudBot
Default languages: English, Hindi, Gujarati
Database: MongoDB Atlas (you have an account)

This repo contains a self-updating Jarvis scaffold:
- Fly.io deployable Docker image
- GitHub Actions for CI/CD and module auto-generation
- Modules folder with templates (weather, note, remind, search)

## Minimal one-time setup (you run these once locally)

1) Clone your empty GitHub repo locally and switch to a setup branch:
   git clone https://github.com/<YOUR_USERNAME>/Jarvis-Cloud-Assistant.git
   cd Jarvis-Cloud-Assistant
   git checkout -b jarvis-setup

2) Copy all files into the repo directory (or upload via GitHub web). Then run:
   git add .
   git commit -m "Initial Jarvis scaffold"
   git push origin jarvis-setup

3) Create Fly app & get FLY_API_TOKEN:
   - Install flyctl: https://fly.io/docs/getting-started/installing/
   - flyctl auth login
   - flyctl launch --name jarvis-cloud-assistant --no-deploy

4) Set GitHub secrets (Repository -> Settings -> Secrets):
   - FLY_API_TOKEN = <your_fly_api_token>
   - TELEGRAM_TOKEN = <your_telegram_bot_token>
   - MONGODB_URI = <your_mongo_uri>  (optional)
   - OPENWEATHER_KEY = <openweather_api_key> (optional)

5) Merge jarvis-setup into main on GitHub (or create PR). Pushing to main triggers CI/CD which builds and deploys to Fly.

## Add module by voice/chat
- Send message to the Telegram bot:
   "add module weather"
  The bot will trigger GitHub Actions to create a PR with the new module (automation token required).

## Notes
- Do NOT store tokens in code. Use GitHub Secrets & Fly secrets.
- If you want me to perform the GitHub push & Fly deploy steps for you, provide instructions and I'll generate exact commands to run locally.
