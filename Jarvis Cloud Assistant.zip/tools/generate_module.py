# tools/generate_module.py
import os, json, sys, textwrap
payload = os.environ.get('EVENT_PAYLOAD_JSON')
if not payload and os.path.exists('payload.json'):
    payload = open('payload.json','r').read()
if not payload:
    print('No payload provided. Expecting EVENT_PAYLOAD_JSON or payload.json')
    sys.exit(1)
data = json.loads(payload)
module = data.get('module') or data.get('client_payload',{}).get('module')
if not module:
    print('No module name specified.')
    sys.exit(1)
modname = module.strip().lower().replace(' ', '_')
fname = os.path.join('modules', f'{modname}.py')
if os.path.exists(fname):
    print('Module already exists:', fname)
    sys.exit(0)
template = textwrap.dedent("""# {modname}.py - auto-generated module
DESCRIPTION = 'Auto-generated module: {modname}'

def register(dp, services, scheduler):
    from telegram.ext import CommandHandler
    def cmd(update, context):
        update.message.reply_text('This is auto-generated module: {modname}. You can edit it later.')
    dp.add_handler(CommandHandler('{modname}', cmd))
""").format(modname=modname)
with open(fname, 'w', encoding='utf-8') as f:
    f.write(template)
print('Created module file:', fname)
