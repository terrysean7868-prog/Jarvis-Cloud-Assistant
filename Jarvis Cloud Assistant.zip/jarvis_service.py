# jarvis_service.py
# Jarvis Cloud Assistant - modular launcher
import os, logging, importlib, pkgutil, sys, time
from datetime import datetime
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv
load_dotenv()

TELEGRAM_TOKEN = os.environ.get('TELEGRAM_TOKEN')
MONGODB_URI = os.environ.get('MONGODB_URI')
GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN')  # optional for automation actions
OPENWEATHER_KEY = os.environ.get('OPENWEATHER_KEY')

if not TELEGRAM_TOKEN:
    print('ERROR: TELEGRAM_TOKEN not set as env var. Exiting.')
    sys.exit(1)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('jarvis')

# services container
services = {
    'mongodb_uri': MONGODB_URI,
    'openweather': OPENWEATHER_KEY,
    'github_token': GITHUB_TOKEN
}

# init scheduler
scheduler = BackgroundScheduler()
scheduler.start()

# init bot
updater = Updater(TELEGRAM_TOKEN, use_context=True)
dp = updater.dispatcher

# built-in handlers
def start(update, context):
    update.message.reply_text('Hello Sir — Jarvis Cloud Assistant online. Use /help to see modules.')

def help_cmd(update, context):
    text = 'Jarvis commands (loaded modules):\n'
    for m in loaded_modules:
        text += "- {} : {}\n".format(m['name'], m.get('desc',''))
    text += '\nYou can request new modules by sending: add module <name>'
    update.message.reply_text(text)

dp.add_handler(CommandHandler('start', start))
dp.add_handler(CommandHandler('help', help_cmd))

# load modules dynamically from modules/
loaded_modules = []
modules_dir = os.path.join(os.path.dirname(__file__), 'modules')
sys.path.insert(0, modules_dir)
for finder, name, ispkg in pkgutil.iter_modules([modules_dir]):
    try:
        mod = importlib.import_module(name)
        if hasattr(mod, 'register'):
            mod.register(dp, services, scheduler)
            loaded_modules.append({'name': name, 'module': mod, 'desc': getattr(mod, 'DESCRIPTION', '')})
            logger.info('Loaded module: %s', name)
    except Exception as e:
        logger.exception('Failed to load module %s: %s', name, e)

# message handler: simple NLP for 'add module' requests
def text_handler(update, context):
    text = update.message.text.lower().strip()
    if text.startswith('add module '):
        modname = text.split('add module ',1)[1].strip()
        update.message.reply_text('Attempting to add module {} via automation pipeline.'.format(modname))
        # create a repository_dispatch event via GitHub API (if token present)
        if services.get('github_token'):
            import requests, json
            repo = os.environ.get('GITHUB_REPO')  # owner/repo
            if not repo:
                update.message.reply_text('GITHUB_REPO not configured on server. Cannot auto-create module PR.')
                return
            url = 'https://api.github.com/repos/{}/dispatches'.format(repo)
            headers = {'Authorization': 'token {}'.format(services.get('github_token')), 'Accept': 'application/vnd.github.everest-preview+json'}
            payload = {'event_type':'generate-module', 'client_payload': {'module': modname}}
            r = requests.post(url, headers=headers, json=payload)
            if r.status_code in (200,204):
                update.message.reply_text('Module generation triggered. Watch GitHub PRs for progress.')
            else:
                update.message.reply_text('Failed to trigger automation. Check server logs.')
        else:
            update.message.reply_text('Automation token not configured. Contact admin.')
        return
    update.message.reply_text('Sorry Sir, I did not understand. Use /help.')

dp.add_handler(MessageHandler(Filters.text & (~Filters.command), text_handler))

if __name__ == '__main__':
    updater.start_polling()
    logger.info('Jarvis service started.')
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        updater.stop()
        scheduler.shutdown()
