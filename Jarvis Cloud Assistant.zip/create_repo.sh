#!/bin/bash
# Usage: ./create_repo.sh https://github.com/<USER>/Jarvis-Cloud-Assistant.git
set -e
if [ -z "$1" ]; then
  echo "Usage: $0 <GITHUB_REPO_URL>"
  exit 1
fi
git init
git add .
git commit -m "Initial Jarvis scaffold"
git branch -M main
git remote add origin $1
git push -u origin main
echo "Pushed to $1"
